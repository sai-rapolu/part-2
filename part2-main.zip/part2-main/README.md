# part2
This folder contains the solution of part2 of fullstackopen course
